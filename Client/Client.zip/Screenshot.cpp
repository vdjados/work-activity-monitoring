#include "Screenshot.h"

std::vector<BYTE> Screenshot::Capture() {
    HDC scr = GetDC(nullptr);
    HDC mem = CreateCompatibleDC(scr);
    int w = GetDeviceCaps(scr, HORZRES);
    int h = GetDeviceCaps(scr, VERTRES);
    HBITMAP bmp = CreateCompatibleBitmap(scr, w, h);
    SelectObject(mem, bmp);
    BitBlt(mem, 0, 0, w, h, scr, 0, 0, SRCCOPY);

    BITMAPINFOHEADER bi = { sizeof(bi), w, -h, 1, 32 };
    std::vector<BYTE> buf(w * h * 4);
    GetDIBits(mem, bmp, 0, h, buf.data(), (BITMAPINFO*)&bi, DIB_RGB_COLORS);

    DeleteObject(bmp);
    DeleteDC(mem);
    ReleaseDC(nullptr, scr);
    return buf;
}
