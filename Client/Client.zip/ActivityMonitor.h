#pragma once
#include <string>

struct ClientInfo {
    std::string domain;
    std::string machine;
    std::string user;
    unsigned long long idleSeconds;   // ������ 64-������
};

class ActivityMonitor {
public:
    static ClientInfo GetInfo();
};
