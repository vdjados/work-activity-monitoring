#include "Network.h"
#include "Config.h"
#include <string>

#pragma comment(lib, "Ws2_32.lib")

void Network::SendData(const ClientInfo& info,
    const std::vector<BYTE>& scr)
{
    SOCKET sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (sock == INVALID_SOCKET) return;

    sockaddr_in addr = {};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(SERVER_PORT);
    inet_pton(AF_INET, SERVER_HOST, &addr.sin_addr);

    if (connect(sock, (sockaddr*)&addr, sizeof(addr)) == 0) {
        std::string hdr = "{"
            "\"domain\":\"" + info.domain + "\","
            "\"machine\":\"" + info.machine + "\","
            "\"user\":\"" + info.user + "\","
            "\"idle\":" + std::to_string(info.idleSeconds) +
            "}";

        int len = static_cast<int>(hdr.size());
        send(sock, reinterpret_cast<const char*>(&len), sizeof(len), 0);
        send(sock, hdr.c_str(), len, 0);

        int sz = static_cast<int>(scr.size());
        send(sock, reinterpret_cast<const char*>(&sz), sizeof(sz), 0);
        send(sock, reinterpret_cast<const char*>(scr.data()), sz, 0);
    }

    closesocket(sock);
}
