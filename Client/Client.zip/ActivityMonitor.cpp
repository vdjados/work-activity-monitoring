#include "ActivityMonitor.h"
#include <windows.h>
#include <lmcons.h>      // ��� UNLEN
#pragma comment(lib, "Advapi32.lib")

ClientInfo ActivityMonitor::GetInfo() {
    // 1) Idle time ����� GetTickCount64
    LASTINPUTINFO li = { sizeof(li) };
    GetLastInputInfo(&li);
    // GetTickCount64 ���������� ULONGLONG
    ULONGLONG now = GetTickCount64();
    ULONGLONG last = li.dwTime;        // DWORD ������������� ����������
    unsigned long long idleSec = (now - last) / 1000ULL;

    // 2) User name
    char user[UNLEN + 1] = { 0 };
    DWORD userLen = UNLEN + 1;
    GetUserNameA(user, &userLen);

    // 3) Domain
    char domain[256] = { 0 };
    GetEnvironmentVariableA("USERDOMAIN", domain, _countof(domain));

    // 4) Machine name
    char machine[MAX_COMPUTERNAME_LENGTH + 1] = { 0 };
    DWORD compLen = _countof(machine);
    GetComputerNameA(machine, &compLen);

    ClientInfo ci;
    ci.user = user;
    ci.domain = domain;
    ci.machine = machine;
    ci.idleSeconds = idleSec;
    return ci;
}
