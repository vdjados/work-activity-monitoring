#pragma once
// Server address and port
#define SERVER_HOST    "127.0.0.1"
#define SERVER_PORT    5000
// Post interval in seconds
#define HEARTBEAT_SEC  10
